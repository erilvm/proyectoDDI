export default {
    background: "#1b1b13",
    grisClaro: "#e2e2e2",
    facebookColor: "#3f51b5",
    googleColor: "#ed1212",
    twitterColor: "#54B0f3"
}
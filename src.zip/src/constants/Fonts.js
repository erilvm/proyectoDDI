
export default {
    family: {
        light: "Montserrat_300Light",
        regular: "Montserrat_400Regular",
        bold: "Montserrat_700Bold"
    },
    size: {
        large: 22,
        medium: 18,
        small: 12
    }

    
}
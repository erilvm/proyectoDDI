const styles = StyleSheet.create({
    container: {
      flex: 1,// Un fondo oscuro para mejorar la legibilidad del texto
      justifyContent: 'center',
      alignItems: 'center',
    },
    logo: {
      width: 160,
      height: 160,
      marginBottom: 20,
    },
  });
  